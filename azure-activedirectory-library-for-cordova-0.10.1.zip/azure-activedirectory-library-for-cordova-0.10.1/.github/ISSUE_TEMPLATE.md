### Issue Description
Problem description...

### Repro Environment Details
1. Installed plugin version:  (Have you tried installing the latest plugin version to ensure this has not already  been fixed?)
2. Target Platform: for example, `Android` or `Windows 10` or `Windows Phone 8.1`
3. Test device and OS version: for example, `Nexus 5 Android 6.0`, `Windows Mobile 10 emulator`, `Windows 8.1 Desktop x64`
4. Are you using Cordova from command line or special Cordova IDE (Visual Studio Cordova Tools, etc), what version?
3. If Windows related, please specify whether SSO option is enabled or not.
